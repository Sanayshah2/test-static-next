export default function Home() {
  return (
    <div>
      <h1>Static Next.js App</h1>
      <p>This is a static site without SSR.</p>
    </div>
  )
}
